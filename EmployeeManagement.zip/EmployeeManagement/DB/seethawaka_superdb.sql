-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2022 at 01:16 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seethawaka_superdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `employeetb`
--

CREATE TABLE `employeetb` (
  `empNo` int(11) NOT NULL,
  `empName` varchar(100) NOT NULL,
  `bDate` date NOT NULL,
  `address` varchar(150) NOT NULL,
  `basicSalary` int(11) NOT NULL,
  `otRate` double NOT NULL,
  `nopLeave` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `ID` int(11) NOT NULL,
  `Product_Name` varchar(20) NOT NULL,
  `Bar_Code` int(11) NOT NULL,
  `Price` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `SID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`ID`, `Product_Name`, `Bar_Code`, `Price`, `Qty`, `SID`) VALUES
(4564894, 'Soap', 564865486, 500000, 100, 561651);

-- --------------------------------------------------------

--
-- Table structure for table `payrolemanagement`
--

CREATE TABLE `payrolemanagement` (
  `empId` int(11) NOT NULL,
  `empName` varchar(100) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `basicSalary` int(11) DEFAULT NULL,
  `otPayment` double DEFAULT NULL,
  `travelAllowance` int(11) DEFAULT NULL,
  `otherAllowance` int(11) DEFAULT NULL,
  `noPayPayment` int(11) DEFAULT NULL,
  `salaryAdvance` int(11) DEFAULT NULL,
  `EPF` double DEFAULT NULL,
  `ETF` double DEFAULT NULL,
  `salary` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payrolemanagement`
--

INSERT INTO `payrolemanagement` (`empId`, `empName`, `designation`, `basicSalary`, `otPayment`, `travelAllowance`, `otherAllowance`, `noPayPayment`, `salaryAdvance`, `EPF`, `ETF`, `salary`) VALUES
(1166, 'Chandi Kodikara', 'Supervisor', 41000, 19188, 1000, 5000, 6830, 2000, 4920, 1230, 51208),
(1615, 'Gayana Almeda', 'Assistant Manager', 58000, 13340, 1000, 5000, 9665, 0, 6960, 1740, 58975),
(9874, 'Cyril Anton', 'Manager', 65000, 37700, 1000, 5000, 0, 0, 7800, 1950, 98950),
(9877, 'Samantha Kodithuwakku', 'Cashier', 39000, 18252, 1000, 5000, 5200, 5000, 4680, 1170, 47202),
(64464, 'Risindu Fernando', 'Manager', 64000, 22272, 1000, 5000, 21330, 0, 7680, 1920, 61342);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_itemdetails`
--

CREATE TABLE `tbl_itemdetails` (
  `id` int(11) NOT NULL,
  `ItemName` varchar(20) NOT NULL,
  `Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_itemdetails`
--

INSERT INTO `tbl_itemdetails` (`id`, `ItemName`, `Price`) VALUES
(1, 'Lifebuoy Soap (RED)', 120),
(2, 'Mouth Wash (Blue) 20', 350),
(3, 'Face wash (250ml)', 300);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `order_id` int(11) NOT NULL,
  `order_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_id`, `order_time`) VALUES
(10, '2022-10-01 21:11:58'),
(11, '2022-10-01 21:12:13'),
(12, '2022-10-02 09:28:38'),
(13, '2022-10-02 11:05:03'),
(14, '2022-10-02 13:01:42'),
(15, '2022-10-02 13:36:13'),
(16, '2022-10-02 13:55:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_detail`
--

CREATE TABLE `tbl_order_detail` (
  `order_detail_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `itemId` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_order_detail`
--

INSERT INTO `tbl_order_detail` (`order_detail_id`, `order_id`, `itemId`, `item_name`, `qty`, `price`) VALUES
(9, 10, 1, 'Lifebuoy Soap (RED)', '1.00', '120.00'),
(10, 10, 2, 'Mouth Wash (Blue) 20', '3.00', '1050.00'),
(11, 11, 1, 'Lifebuoy Soap (RED)', '2.00', '240.00'),
(12, 12, 1, 'Lifebuoy Soap (RED)', '3.00', '360.00'),
(13, 13, 1, 'Lifebuoy Soap (RED)', '8.00', '960.00'),
(14, 13, 2, 'Mouth Wash (Blue) 20', '8.00', '2800.00'),
(15, 14, 2, 'Mouth Wash (Blue) 20', '1.00', '350.00'),
(16, 15, 2, 'Mouth Wash (Blue) 20', '2.00', '700.00'),
(17, 15, 3, 'Face wash (250ml)', '1.00', '300.00'),
(18, 15, 2, 'Mouth Wash (Blue) 20', '1.00', '350.00'),
(19, 16, 2, 'Mouth Wash (Blue) 20', '2.00', '700.00'),
(20, 16, 2, 'Mouth Wash (Blue) 20', '1.00', '350.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplierinfo`
--

CREATE TABLE `tbl_supplierinfo` (
  `id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Contact` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_supplierinfo`
--

INSERT INTO `tbl_supplierinfo` (`id`, `Name`, `Address`, `Contact`) VALUES
(1, 'S.K.S Samantha', '85/8 Jaya Road Kesbewa', 778457845);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplierplacedship`
--

CREATE TABLE `tbl_supplierplacedship` (
  `id` int(11) NOT NULL,
  `SupID` int(20) NOT NULL,
  `ItemName` varchar(20) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReceiveDate` date NOT NULL,
  `TotalOrder` decimal(20,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_supplierplacedship`
--

INSERT INTO `tbl_supplierplacedship` (`id`, `SupID`, `ItemName`, `Qty`, `ReceiveDate`, `TotalOrder`) VALUES
(1, 1, 'Lifebuoy Soap (RED)', 6, '2022-10-13', '720');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `employeetb`
--
ALTER TABLE `employeetb`
  ADD PRIMARY KEY (`empNo`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `payrolemanagement`
--
ALTER TABLE `payrolemanagement`
  ADD PRIMARY KEY (`empId`);

--
-- Indexes for table `tbl_itemdetails`
--
ALTER TABLE `tbl_itemdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `tbl_order_detail`
--
ALTER TABLE `tbl_order_detail`
  ADD PRIMARY KEY (`order_detail_id`);

--
-- Indexes for table `tbl_supplierinfo`
--
ALTER TABLE `tbl_supplierinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_supplierplacedship`
--
ALTER TABLE `tbl_supplierplacedship`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKSUPID` (`SupID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4564895;

--
-- AUTO_INCREMENT for table `tbl_itemdetails`
--
ALTER TABLE `tbl_itemdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_order_detail`
--
ALTER TABLE `tbl_order_detail`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_supplierinfo`
--
ALTER TABLE `tbl_supplierinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_supplierplacedship`
--
ALTER TABLE `tbl_supplierplacedship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_supplierplacedship`
--
ALTER TABLE `tbl_supplierplacedship`
  ADD CONSTRAINT `tbl_supplierplacedship_ibfk_1` FOREIGN KEY (`SupID`) REFERENCES `tbl_supplierinfo` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
