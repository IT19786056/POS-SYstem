-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 02, 2022 at 01:00 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supplierdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_itemdetails`
--

DROP TABLE IF EXISTS `tbl_itemdetails`;
CREATE TABLE IF NOT EXISTS `tbl_itemdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(20) NOT NULL,
  `Price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_itemdetails`
--

INSERT INTO `tbl_itemdetails` (`id`, `ItemName`, `Price`) VALUES
(1, 'Lifebuoy Soap (RED)', 120);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplierinfo`
--

DROP TABLE IF EXISTS `tbl_supplierinfo`;
CREATE TABLE IF NOT EXISTS `tbl_supplierinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Contact` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_supplierinfo`
--

INSERT INTO `tbl_supplierinfo` (`id`, `Name`, `Address`, `Contact`) VALUES
(1, 'S.K.S Samantha', '85/8 Jaya Road Kesbewa', 778457845),
(2, 'Jagoda', 'fjisnfuewnf', 777289081),
(3, 'Guidfhwi', 'wbifweif', 777777777);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplierplacedship`
--

DROP TABLE IF EXISTS `tbl_supplierplacedship`;
CREATE TABLE IF NOT EXISTS `tbl_supplierplacedship` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `SupID` int(20) NOT NULL,
  `ItemName` varchar(20) NOT NULL,
  `Qty` int(11) NOT NULL,
  `ReceiveDate` date NOT NULL,
  `TotalOrder` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKSUPID` (`SupID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tbl_supplierplacedship`
--

INSERT INTO `tbl_supplierplacedship` (`id`, `SupID`, `ItemName`, `Qty`, `ReceiveDate`, `TotalOrder`) VALUES
(1, 1, 'Lifebuoy Soap (RED)', 3, '2022-10-04', 360),
(2, 1, 'Lifebuoy Soap (RED)', 3, '2022-10-04', 360),
(4, 1, 'Bunty', 3, '2022-10-27', 360),
(5, 1, 'Lifebuoy Soap (RED)', 80, '2022-10-06', 9600),
(6, 1, 'Lifebuoy Soap (RED)', 80, '2022-10-05', 9600);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_supplierplacedship`
--
ALTER TABLE `tbl_supplierplacedship`
  ADD CONSTRAINT `tbl_supplierplacedship_ibfk_1` FOREIGN KEY (`SupID`) REFERENCES `tbl_supplierinfo` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
