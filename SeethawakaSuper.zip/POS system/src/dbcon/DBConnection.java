/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbcon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author kavinda
 */
public class DBConnection {
// Object of Connection class
// initially assigned NULL

    Connection con = null;

    public static Connection connectDB() {
        try {

            // Step 2: involve among 7 in Connection
            // class i.e Load and register drivers
            // 2(a) Loading drivers using forName() method
            // Here, the name of the database is mysql
//            Class.forName("com.mysql.jdbc.Driver");

            // 2(b) Registering drivers using DriverManager
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/seethawaka_superdb",
                    "root", "");

            // Root is the username, and
            // 1234 is the password
            // Here, the object of Connection class is return
            // which further used in main class
            return con;
        } // Here, the exceptions is handle by Catch block
        catch (SQLException e) {

            // Print the exceptions
            System.out.println(e);

            return null;
        }
    }
}
